library(tidyverse)
library(tidycensus)
NHGIS <- read_csv("data/nhgis2017_county.csv")
IL <- read_csv("data/IL_lab6.csv")

################### Below is the answer of Question 1 ############################
NHGIS1 <- select(NHGIS, -(NAME_M:AH04M025), -(GISJOIN:BTBGA), STATEA, COUNTYA)
##################################################################################

################### Below is the answer of Question 2 Prep #######################
# GEOID is a 5-digit number, first 2 digits are state number (STATEA) in NHGIS, 
# the rest are county number (COUNTYA).
##################################################################################

################### Below is the answer of Question 2 ############################
NHGIS2 <- mutate(NHGIS1, GEOID = str_c(STATEA, COUNTYA))
# Use str_c() function to contentate STATEA and COUNTYA together, which yields GEOID
# in the IL dataset
##################################################################################

################### Below is the answer of Question 3 ############################
IL1 <- left_join(IL, NHGIS1, by = "GEOID")
# or IL_final <- inner_join(IL, NHGIS1, by = "GEOID")
# or IL_final <- right_join(NHGIS1, IL, by = "GEOID") 
##################################################################################

################### Below is the answer of Question 4 ############################
IL_final <- mutate(IL1, pHE = (AH04E022+AH04E023+AH04E024+AH04E025)/AH04E001)
# pHE stands for the percentage of population who hold a higher education degrees
# (bachelor's, master's, professional and doctoral degrees)
##################################################################################

plot(IL_final$hhincome, IL_final$pHE)
plot(IL_final$pHE, IL_final$housingv)
plot(IL_final$pHE, IL_final$grossrent)

########## Below are cleaning step of IL dataset, if from get_acs() function #########
# IL <- get_acs(geography = "county", 
#                    year = 2017,
#                    variables = c(medhousingv = "B25077_001",medhhincome = "B19013_001",medgrossrent = "B25064_001"), 
#                    state = "IL",
#                    survey = "acs5")
# IL <- select(IL, GEOID:estimate, -NAME)
# IL <- spread(IL, key = variable, value = estimate)
######################################################################################


